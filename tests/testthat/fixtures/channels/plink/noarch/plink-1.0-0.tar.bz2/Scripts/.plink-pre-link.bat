@echo ran> "%PREFIX%\pre-link-ran"
