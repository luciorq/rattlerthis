@echo ran> "%PREFIX%\pre-unlink-ran"
