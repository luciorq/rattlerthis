@echo ran> "%PREFIX%\post-link-ran"
